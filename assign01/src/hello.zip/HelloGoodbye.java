public class HelloGoodbye {
    public static void main(String[] args) {

        if(args.length > 0){
            System.out.println("bye , " + args[0]);
        }
        else
            System.out.println("Hello GoodBye!");
    }
}
